<?php 
 
 /*
 * Created by Belal Khan
 * website: www.simplifiedcoding.net 
 * Retrieve Data From MySQL Database in Android
 */
 
 //database constants
 define('DB_HOST', 'localhost');
 define('DB_USER', 'root');
 define('DB_PASS', '');
 define('DB_NAME', 'drsense');
 
 //connecting to database and getting the connection object
 $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
 
 //Checking if any error occured while connecting
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 


$myfile = fopen("currentUserType.txt", "r") or die("Unable to open file!");
$type=fread($myfile,filesize("currentUserType.txt"));
fclose($myfile);

//echo $type;


$myfile = fopen("currentUser.txt", "r") or die("Unable to open file!");
$user=fread($myfile,filesize("currentUser.txt"));
fclose($myfile);

//echo $user;

if($type=='Patient')

{    //creating a query
    //echo "wrong working here";
 $stmt = $conn->prepare("select date,exudates_result,hemoraghes_result,micro_result,user_email,severity_grade from results where user_email='$user'");
 
 //executing the query 
 $stmt->execute();
 
 //binding results to the query 
 $stmt->bind_result($date, $exudates_result, $hemoraghes_result,$micro_result,$user_email,$severity_grade);
 
 $products = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['date'] = $date; 
 $temp['exudates_result'] = $exudates_result; 
 $temp['hemoraghes_result'] = $hemoraghes_result; 
 $temp['micro_result']=$micro_result;
 $temp['user_email']=$user_email;
 $temp['severity_grade']=$severity_grade;
  
 array_push($products, $temp);
 }
 
 //displaying the result in json format 
 echo json_encode($products);

}


 //creating a query
else
{  //echo $user;
 $query="select doc_email,patient_email from appointment where doc_email= '$user'";
 $queryResult=mysqli_query($conn,$query);
 $storeArray = Array();
 
// read each element and store in array
  while( $result=mysqli_fetch_array($queryResult,MYSQL_ASSOC))
	{
              $storeArray[]=$result['patient_email'];
             // echo $storeArray;
	} 
     
//echo count($storeArray);

//$pt=$storeArray[0];
//echo $pt;

$products=array();

for ($i=0;$i<count($storeArray);$i++)
	{
		$pt=$storeArray[$i];
                // echo $pt;
                
		$query1="select date,exudates_result,hemoraghes_result,micro_result,user_email,severity_grade from results where user_email='$pt'";
		$result=mysqli_query($conn,$query1);

                 $finalResult=mysqli_fetch_array($result,MYSQL_ASSOC);
                 // echo $finalResult['exudates_result'];
                While($finalResult=mysqli_fetch_array($result,MYSQL_ASSOC))
	      
		{
 			$temp=array();
			$temp['date']=$finalResult['date'];
 			$temp['exudates_result']=$finalResult['exudates_result'];
			$temp['hemoraghes_result']=$finalResult['hemoraghes_result'];
			$temp['micro_result']=$finalResult['micro_result'];
			$temp['user_email']=$finalResult['user_email'];
                        $temp['severity_grade']=$finalResult['severity_grade'];
                        
               
			array_push($products,$temp);


		
	        } 
                
               
                
               
                
              
    }
 


                 
	 echo json_encode($products);

     
}

?>

