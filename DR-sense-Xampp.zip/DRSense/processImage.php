<?php

//$email=$_POST['user_email'];


//$name="shanti.cs15@iba-suk.edu.pk.txt";
$name1="vishal";
	require_once 'dbDetails.php';

$myfile = fopen("currentUser.txt", "r") or die("Unable to open file!");
$user=fread($myfile,filesize("currentUser.txt"));
fclose($myfile);
echo $user;

		$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect...');
		$con1=mysqli_connect("localhost","root","","drsense") or die('Unable to Connect...');

		$sql = "SELECT max(id) as id FROM images";
		
		$result = mysqli_fetch_array(mysqli_query($con,$sql));

		//$username=mysqli_fetch_array(mysqli_query($con1,"select name from userinfo where user_email like '$name'"));

		$temp=$result['id'];
            

           echo $temp;		
		
//$path="C:\\Users\\Simran\\Num_MA.txt";

exec("\"C:\\Program Files (x86)\\MATLAB\\MATLAB Production Server\\R2015a\bin\\matlab.exe\" -nodisplay -nosplash -nodesktop -r \"run('C:\\xampp\\htdocs\\AndroidImageUpload\\uploads\\DRSense($temp)')\"" );

Sleep(100);

$micro=file("C:\\Users\\Simran\\Num_MA.txt");		
$date=date('y/m/d');

$microaneurysms=$micro[0];
echo $microaneurysms;

$exudates=file("C:\\Users\\Simran\\exudates_Area.txt");

$exudatesArea=$exudates[0];

echo $exudatesArea;
$hemo=file("C:\\Users\\Simran\\Hemo_area.txt");

$hemoArea=$hemo[0];

echo $hemoArea;

//$response=$temp." ".$username[0]." ".$date." ".$x;

mysqli_close($con);

$con1=mysqli_connect("localhost","root","","drsense");	
$query="Insert into results VALUES ('$temp','$date','$exudatesArea','$hemoArea','$microaneurysms','','$user','Moderate')";
$newResult=mysqli_query($con1,$query);
$grade=$newResult[7];
if(mysqli_query($con1,$query))
{
  echo $grade;
}
else
echo "error";

mysqli_close($con1);

		

?>