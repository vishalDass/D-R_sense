
<?php
$con= mysqli_connect("localhost","root","","drsense");
if(mysqli_connect_errno())
{
   echo "Failed to connect to MySQL: ".mysqli_connect_error();
   die();
}

$myfile = fopen("currentUserType.txt", "r") or die("Unable to open file!");
$type=fread($myfile,filesize("currentUserType.txt"));
fclose($myfile);

//echo $type;


$myfile = fopen("currentUser.txt", "r") or die("Unable to open file!");
$user=fread($myfile,filesize("currentUser.txt"));
fclose($myfile);

if($type == 'Patient')
{
   //echo "file patient is here";
	$stmt=$con->prepare("Select Token_No,Date,patient_email from appointment where patient_email Like '$user'");
	$stmt->execute();

	$stmt->bind_result($Token_No, $Date, $patient_email);
	//echo " Patient here";

	$products = array();


	while($stmt->fetch())
		{    
		    $temp = array();
		    $temp['Token_No'] = $Token_No; 
		    $temp['Date'] = $Date; 
	            $temp['patient_email'] = $patient_email; 
 		   array_push($products, $temp);
	      } 


echo json_encode($products);
}
else
{
	
$stmt=$con->prepare("Select Token_No,Date,patient_email from appointment");
	$stmt->execute();
       echo "Doctor here";

	$stmt->bind_result($Token_No, $Date, $patient_email);
	

	$products = array();


	while($stmt->fetch())
		{    
		    $temp = array();
		    $temp['Token_No'] = $Token_No; 
		    $temp['Date'] = $Date; 
	            $temp['patient_email'] = $patient_email; 
 		   array_push($products, $temp);
	      } 


echo json_encode($products);


}



?>