<?php
session_start();



$email=$_POST["user_email"];

$password=$_POST["password"];

$myfile = fopen("currentUser.txt", "w") or die("Unable to open file!");
fwrite($myfile, $email);
fclose($myfile);


$conn=mysqli_connect("localhost","root","","drsense");
$query="SELECT user_type FROM userinfo WHERE  user_email LIKE '$email' AND password LIKE '$password'";



if($conn)
{  
     
     
   $queryResult=mysqli_query($conn,$query);
   $result=mysqli_fetch_array($queryResult);
   $user_type=$result[0];

  $myfile = fopen("currentUserType.txt", "w") or die("Unable to open file!");
  fwrite($myfile, $user_type);
  fclose($myfile);

   
   
   if(mysqli_num_rows($queryResult)>0)
    {      
           if($user_type=='Patient')
        {
           echo "login Successfully1";
         
        }
      else
         
	 echo "login Successfully2";

    }
    
    else
 	    echo "user Name or Password is incorrect";
}
else
  echo "disconnected";


?>