<?php 
$myfile = fopen("currentUser.txt", "r") or die("Unable to open file!");
$user=fread($myfile,filesize("currentUser.txt"));
fclose($myfile);

//$user=$_POST['user_email'];




	/*
	* Created by Belal Khan
	* website: www.simplifiedcoding.net 
	* Retrieve Data From MySQL Database in Android
	*/
	
	//database constants
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'db_images');
	
	//connecting to database and getting the connection object
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	$con2= new mysqli("localhost","root","","drsense");
	//Checking if any error occured while connecting
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	//$user=mysqli_fetch_array(mysqli_query($con2,"select name from userinfo"));
	//creating a query
	$stmt = $conn->prepare("SELECT id, date, Result FROM images where user like '$user'");
	
	//executing the query 
	$stmt->execute();
	
	//binding results to the query 
	$stmt->bind_result($id, $date, $Result);
	
	$products = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		$temp['id'] = $id; 
		$temp['date'] = $date; 
		$temp['Result'] = $Result; 
		array_push($products, $temp);
	}
	
	//displaying the result in json format 
	
echo json_encode($products);
	
	