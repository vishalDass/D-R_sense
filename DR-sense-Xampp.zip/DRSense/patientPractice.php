<?php
$con=mysqli_connect("localhost","root","","drsense");
$query="select patient_email from appointment";




if($con)
{  
     
      echo "connected";
   $queryResult=mysqli_query($con,$query);

 
  // $result=mysqli_fetch_array($queryResult,MYSQL_ASSOC);

   $storeArray = Array();
   //int i=0;

   
   if(mysqli_num_rows($queryResult)>0)
    {      
        
       
         for ($i=0;$i<count($storeArray);$i++)
           {
                $patientQuery="select patient_email,exudates_result,hemoraghes_result,micro_result,date from results where user_email=$storeArray[$i]";
		$patientQueryResult=mysqli_query($con,$patientQuery);
                $result=mysqli_fetch_array($patientQueryResult,MYSQL_ASSOC);
              
		 
               
		 
              }








 $stmt = $conn->prepare("SELECT Token_No, Date, patient_email,time FROM appointment;");
 
 //executing the query 
 $stmt->execute();
 
 //binding results to the query 
 $stmt->bind_result($Token_No, $Date, $patient_email,$time);
 
 $products = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['Token_No'] = $Token_No; 
 $temp['Date'] = $Date; 
 $temp['patient_email'] = $patient_email; 
 $temp['time']=$time;
  
 array_push($products, $temp);
 }
 
 //displaying the result in json format 
 echo json_encode($products);

}

}
else
  echo "disconnected";






?>