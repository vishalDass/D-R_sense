<?php
session_start();
$_SESSION["login"]=0;

$user_email=$_POST["user_email"];
$date_from=$_POST["date_from"];
$date_to=$_POST["date_to"];
$hours=$_POST["hours"];


echo $user_email;

$query="INSERT into schedule VALUES('','$user_email','$date_from','$date_to','$hours')";



$conn=mysqli_connect("localhost","root","","drsense");
if($conn)
{  echo "connected";
   
   $result=mysqli_query($conn,$query);
   if($result)
	{
           echo "schedule Insert Successfully";
	}
	else
 	    echo "not entered ";
}


else
  echo "disconnected";


?>