<?php

$email=$_POST["user_email"];
echo "success";




?>