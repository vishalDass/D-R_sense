<?php 
 
 /*
 * Created by Belal Khan
 * website: www.simplifiedcoding.net 
 * Retrieve Data From MySQL Database in Android
 */
 
 //database constants
 define('DB_HOST', 'localhost');
 define('DB_USER', 'root');
 define('DB_PASS', '');
 define('DB_NAME', 'drsense');
 
 //connecting to database and getting the connection object
 $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
 
 //Checking if any error occured while connecting
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }

$myfile = fopen("currentUserType.txt", "r") or die("Unable to open file!");
$type=fread($myfile,filesize("currentUserType.txt"));
fclose($myfile);

//echo $type;


$myfile = fopen("currentUser.txt", "r") or die("Unable to open file!");
$user=fread($myfile,filesize("currentUser.txt"));
fclose($myfile);

if($type == 'Patient')
{
    //echo "Yes correct response"; 
 //creating a query
 $stmt = $conn->prepare("SELECT Token_No, Date, doc_email,patient_email, time FROM appointment where patient_email = '$user';");
 
 //executing the query 
 $stmt->execute();
 
 //binding results to the query 
 $stmt->bind_result($Token_No, $Date, $doc_email,$patient_email,$time);
 
 $products = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['Token_No'] = $Token_No; 
 $temp['Date'] = $Date; 
 $temp['email'] = $doc_email; 
 $temp['time']=$time;
  
 array_push($products, $temp);
 }
 
 //displaying the result in json format 
 echo json_encode($products);

}
else

{ // echo "wrong Response"; 
  
 //creating a query
 $stmt = $conn->prepare("SELECT Token_No, Date, doc_email, patient_email,time FROM appointment where doc_email='$user';");
 
 //executing the query 
 $stmt->execute();

  $stmt->bind_result($Token_No, $Date,$doc_email, $patient_email,$time);
   //echo "here";
 $products = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['Token_No'] = $Token_No; 
 $temp['Date'] = $Date; 
 $temp['email'] = $patient_email; 
 $temp['time']=$time;
  
 array_push($products, $temp);
 


}
 
 //displaying the result in json format 
 echo json_encode($products);




}