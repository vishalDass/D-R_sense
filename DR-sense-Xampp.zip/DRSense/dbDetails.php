<?php 
	define('HOST','localhost');
	define('USER','root');
	define('PASS','');
	define('DB','db_images');

?>


