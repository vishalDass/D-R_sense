<?php
session_start();
$_SESSION["login"]=0;

$user_email=$_POST["user_email"];
$name=$_POST["name"];
$password=$_POST["password"];
$gender=$_POST["gender"];
$age=$_POST["age"];
$phone=$_POST["phone"];
$address=$_POST["address"];
$special=$_POST["special"];



$query="INSERT into userinfo VALUES('$user_email','$name','$password','$gender','$age','$phone','$address','$special')";


$conn=mysqli_connect("localhost","root","","drsense");
if($conn)
{  echo "connected";
   
   $result=mysqli_query($conn,$query);
   if($result)
	{
           echo "insert Successfully";
	}
	else
 	    echo "not sign up";
}


else
  echo "disconnected";


?>