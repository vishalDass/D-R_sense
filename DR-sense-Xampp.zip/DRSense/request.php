<?php
session_start();
$_SESSION["login"]=0;

$Date=$_POST["Date"];
$doc_email=$_POST["doc_email"];
$patient_email=$_POST["patient_email"];
$time=$_POST["time"];




//echo $doc_email;

/*$Date="21/6/19";
$doc_email="shanti2";
$patient_email="khushi2";
$time="18:09:27";
*/



$conn=mysqli_connect("localhost","root","","drsense");

$query1="select doc_email,patient_email from appointment where doc_email ='$doc_email' AND patient_email ='$patient_email'";
$queryResult=mysqli_query($conn,$query1);
$result=mysqli_fetch_array($queryResult);

if($result)
{
    echo "you have already requested..!!!";

}
else
    {

      $query="INSERT into appointment VALUES(' ','$Date','$doc_email','$patient_email','$time')";
              
            $result=mysqli_query($conn,$query);
           if($result)
		{
           		echo "Appointment fixed....!!! Vist to Hospital at given Schedule.......!!! Thanks..!!"."</br>";
           
		}
             
         
      else 
         echo "error";



    }












?>