function [distance_array,numObjects, PixIndexes,numPix] = patch_center(image,x1,y1)

eu_distance=0;

  [M,N]=size(image);
  StructImg=bwconncomp(image);
 PixIndexes = StructImg.PixelIdxList;
 numObjects=StructImg.NumObjects;
 sumPix=zeros(1,(StructImg.NumObjects));
 numPix = sort(cellfun(@numel, PixIndexes),'descend');
 
 %[biggest, idx] = max(numPix);
 distance_array=1;
 %distance_array=zeros(1,(StructImg.NumObjects));
  
 for i=1:StructImg.NumObjects
     [row_idx, col_idx] = ind2sub([M,N],PixIndexes{i});
     min_row = min(row_idx);
     max_row = max(row_idx);
 
    min_col = min(col_idx);
    max_col = max(col_idx);
    diff_col = max_col - min_col;
    diff_row = max_row - min_row;
if(diff_row>diff_col)
    rad_StrEl = (max_row - min_row)/2;
else
    rad_StrEl = (max_col - min_col)/2;
end
rad_StrEl = round(rad_StrEl);
x2 = min_row + rad_StrEl;
y2 = min_col + rad_StrEl;

power_ex=(power((x2-x1),2)+power((y2-y1),2));
eu_distance=sqrt(power((x2-x1),2)+power((y2-y1),2));
distance_array(1,i)=eu_distance;

 end

 

 
end
 

 



