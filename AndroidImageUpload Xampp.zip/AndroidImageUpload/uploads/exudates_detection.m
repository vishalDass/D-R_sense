
function [exudates, dilated_diskImg,exudates_area,diam,seg_mean_ex,seg_sd_ex] = exudates_detection(green_channel)
% figure,imshow(green_channel),title('Green');
% image_clahe_temp=adapthisteq(imcomplement(green_channel));
image_clahe=adapthisteq(green_channel);
exudates = zeros(size(green_channel));

% 
%  unSharpImage=imsharpen(image_clahe_temp);
%  extraction_imageROI = unSharpImage>210;
[ region_of_interest,bin_R]=ROI(green_channel,0);
 [M,N]=size(green_channel);
 image1 = zeros(M,N);
 image2 = zeros(M,N);
 image3 = zeros(M,N);
 binary_image = zeros(M,N);
new_image=zeros(M,N);
pix_idx=0;
seg_mean_ex=0;
seg_sd_ex=0;
 
 im3_double = double(image_clahe);
 exp_image = exp(255-im3_double);
% figure, imshow(exp_image,[]);
 z = zeros(M,N);
 
z=[];
        for x = 1:M
            for y = 1:N
                m=im3_double(x,y);
                    if(m>=0 && m<=50)
                     
                     image1(x,y) = log10(1+m)/log10(5);
                    end
                     
                    if(m>50 && m<=150)
                            z(x,y)=log10(1+m)/log10(4);
                            image2(x,y) = log10(1+m)/log10(4);
                    end
                    
                    
                    if(m>150 && m<=200)
                       
                            z(x,y)=log10(1+m)/log10(2);
                            image3(x,y) = log10(1+m)/log10(2);
                    end
                    
                    
                    if(m>200 && m<=255)
                            z(x,y)=log10(1+m)/log10(1);
                            binary_image(x,y) =1; 
                            
                    end
               
                 
                    
                   
            end
        end

StructImg=bwconncomp(binary_image);
 PixIndexes = StructImg.PixelIdxList;
 numPix = cellfun(@numel, PixIndexes);
 [biggest, idx] = max(numPix);
 
 if(biggest~=0)
%  disp(biggest);     
%  getting initial estimate of radius of optic disc on the basis of maximum
%  group available
 [row_idx, col_idx] = ind2sub([M,N],PixIndexes{idx});
min_row = min(row_idx);
max_row = max(row_idx);
 
min_col = min(col_idx);
max_col = max(col_idx);
diff_col = max_col - min_col;
diff_row = max_row - min_row;
if(diff_row>diff_col)
    rad_StrEl = (max_row - min_row)/2;
else
    rad_StrEl = (max_col - min_col)/2;
end
rad_StrEl = round(rad_StrEl);
diam=rad_StrEl*2;
% got initial center of biggest cluster
cent_row = min_row + rad_StrEl;
cent_col = min_col + rad_StrEl;

size_pixInd = length(PixIndexes);
image_zeros = zeros(size(binary_image));
image_temp = image_zeros;
for i = 1:size_pixInd
    temp_array = cell2mat(PixIndexes(i));
    image_temp(temp_array) = i;
end
patch_row_cent=cent_row-rad_StrEl*2;
patch_row_cent2=cent_row+rad_StrEl*2;
patch_col_cent=cent_col-rad_StrEl*2;
patch_col_cent2=cent_col+rad_StrEl*2;

% Getting patch that has diameter twice the biggest cluster
if(patch_row_cent<0)
    patch_row_cent=1;
    
end

if(patch_col_cent<0)
    patch_col_cent=1;
end

if(patch_row_cent>500 )
    patch_row_cent=500;
end
if(patch_row_cent2>500)
    patch_row_cent2=500;
end

if(patch_col_cent>700 )
    patch_col_cent=700;
end
if(patch_col_cent2>700)
    patch_col_cent2=700;
end

patch_image = image_temp(patch_row_cent:patch_row_cent2,patch_col_cent:patch_col_cent2);

% patch_image = image_temp(cent_row-rad_StrEl*2:cent_row+rad_StrEl*2,cent_col-rad_StrEl*2:cent_col+rad_StrEl*2);
image_zeros(cent_row, cent_col) = 1;
unique_st = unique(patch_image);
unique_st(unique_st==0) = [];
for i = 1:length(unique_st)
    image_zeros(PixIndexes{unique_st(i)}) = 1;
    
end
[row_group, col_group] = find(image_zeros==1);


min_row = min(row_group);
max_row = max(row_group);

min_col = min(col_group);
max_col = max(col_group);
diff_col = max_col - min_col;
diff_row = max_row - min_row;
% Getting final radius
if(diff_row>diff_col)
    rad_StrEl = (max_row - min_row)/2;
else
    rad_StrEl = (max_col - min_col)/2;
end





image_zeros(PixIndexes{idx}) = 1;
image_temp = image_temp>0;
exudates = image_temp - image_zeros;
%figure, imshow(exudates),title('Exudates');
strElDisk = strel('disk',ceil(rad_StrEl),8);
dilated_diskImg = imdilate(image_zeros, strElDisk);
%figure, imshow(dilated_diskImg),title('Optic Disk')

%%
[r1,c1]=find(exudates==1);
if(~(isempty(r1)&&isempty(c1)))
min_ex_row=min(r1);
max_ex_row=max(r1);


min_ex_col=min(c1);
max_ex_col=max(c1);

r_cen=(min_ex_row+max_ex_row)/2;
c_cen=(min_ex_col+max_ex_col)/2;

if(isempty(r_cen)==1)
    r_cen=0;
end

if(isempty(c_cen)==1)
    c_cen=0;
end


[final_distance,numObjects,PixIndexes,numPix]=patch_center(exudates,r_cen,c_cen);



[sorted_arr, Ind_bSort] = sort(final_distance);
length_fin = length(final_distance);
sum_pix = 0;
array_numExudates = zeros(length_fin);
array_pixExudates = zeros(length_fin);



if(numObjects==0)
    temp1=0;
else
    temp1=zeros(1,numObjects);
end

for i = 1:length_fin
           
    
   
    array_numExudates(1,i) = i/sorted_arr(i);
    sum_pix = sum_pix + length(PixIndexes{1,Ind_bSort(i)});

    array_pixExudates(1,i) = sum_pix/sorted_arr(i);
    
    temp1(1,i)=length(PixIndexes{1,Ind_bSort(i)})/region_of_interest;
    
end
max_distance=max(final_distance);
exudates_pix_sum=sum(numPix);
exudates_area=exudates_pix_sum/region_of_interest;
pix_idx=find(exudates==1);


seg_mean_ex=mean(double(green_channel(pix_idx)));
seg_sd_ex=std(double(green_channel(pix_idx)));

%areaSomething=(exudates_pix_sum/areaROI);




%%




% figure,subplot(3,2,3), imshow(image_temp),title('total region'),subplot(3,2,4),imshow(exudates),title('Exudates'),subplot(3,2,5),imshow(dilated_diskImg),title('Optic Disk'),
else
exudates_area=0;array_pixExudates=0;array_numExudates=0;temp1=0;diam=0;
    
end 

else
     
     exudates_area=0;array_pixExudates=0;array_numExudates=0;temp1=0;diam=0;
     
 end



end

