function [hemo_area] = hemorhage_detection( green_channel )
[segmentedOutput, area, var_diff]=vesselExtraction(green_channel);
%  complement=imcomplement(green_channel);
%  clahe=adapthisteq(complement);
%  unSharp=imsharpen(clahe);
%  img_bin = unSharp>210;
%   hemo_area=area(img_bin);
%   disp(hemo_area);
  

end

