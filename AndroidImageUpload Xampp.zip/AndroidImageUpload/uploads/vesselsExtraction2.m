function [segmentedOutput, area, var_diff] = vesselsExtraction2(green)
area = 0;
flag = 1;



% 
% LTproject = guidata(gcbo);
% ImageInput = get(LTproject.original,'Userdata');
% 
% green=ImageInput(:,:,2);                                                   
GIm = imcomplement(green);                                                 %Covert RGB to Green Channel Complement
% axes(handles.green_channel);
set(imshow(GIm));

HIm = adapthisteq(GIm);                                                    %Contrast Limited Adaptive Histogram Equalization
% axes(handles.ahe);
%---------->

% if(flag)
% imshow(HIm);
% end
se = strel('ball',8,8);                                                    %Structuring Element
gIntermed = imgaussfilt(HIm,4);


gopen = imopen(gIntermed,se);                                                    %Morphological Open
    
%Morphological Open
godisk = HIm - gopen;       
%---------->                                      %Remove Optic Disk
if(flag)
 
% figure(1),imshow(gIntermed),title('gIntermed');
% figure(2),imshow(gopen),title('gopen');
% figure(3), imshow(godisk), title([' GODISK variance is ' num2str(var(double(godisk(:))))])
end
var_diff = var(double(godisk(:)));

flag=0;
medfilt = medfilt2(godisk);                                                %2D Median Filter
background = imopen(medfilt,strel('disk',100));                            %imopen function
I2 = medfilt - background;                                                 %Remove Background
GC = imadjust(I2);                                                         %Image Adjustment
flag=1;
% axes(handles.morp);
if(flag)
% imshow(GC),title('gc')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ---------------- Segmentation Using Fuzzy C-means(fcm) ---------------- %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

IM=GC;
IM=double(IM);
[maxX,maxY]=size(IM);
IMM=cat(3,IM,IM);

cc1=8;
cc2=250;

ttFcm=0;

while(ttFcm<10)
    ttFcm=ttFcm+1;
    
%     sttFcm=(['ttFcm = ' num2str(ttFcm)]);
%     set(handles.fcm1,'String',sttFcm)
    
    c1=repmat(cc1,maxX,maxY);
    c2=repmat(cc2,maxX,maxY);
    
    if ttFcm==1 
        test1=c1; test2=c2;
    end
    
    c=cat(3,c1,c2);
    ree=repmat(0.000001,maxX,maxY);
    ree1=cat(3,ree,ree);
    
    distance=IMM-c;
    distance=distance.*distance+ree1;
    
    daoShu=1./distance;
    
    daoShu2=daoShu(:,:,1)+daoShu(:,:,2);
    distance1=distance(:,:,1).*daoShu2;
    u1=1./distance1;
    distance2=distance(:,:,2).*daoShu2;
    u2=1./distance2;
      
    ccc1=sum(sum(u1.*u1.*IM))/sum(sum(u1.*u1));
    ccc2=sum(sum(u2.*u2.*IM))/sum(sum(u2.*u2));
   
    tmpMatrix=[abs(cc1-ccc1)/cc1,abs(cc2-ccc2)/cc2];
    pp=cat(3,u1,u2);
    
    for i=1:maxX
        for j=1:maxY
            if max(pp(i,j,:))==u1(i,j)
                IX2(i,j)=1;
            else
                IX2(i,j)=2;
            end
        end
    end
    
    if max(tmpMatrix)<0.0001
        break;
    else
        cc1=ccc1;
        cc2=ccc2;
    end

    for i=1:maxX
        for j=1:maxY
            if IX2(i,j)==2
                IMMM(i,j)=254;
            else
                IMMM(i,j)=8;
            end
        end
    end
    
    background=imopen(IMMM,strel('disk',45));
    I4=IMMM-background;
    I4=bwareaopen(I4,30);

%     axes(handles.segmented_image);
if(flag)
%    imshow(I4)
end
%     set(LTproject.segmented_image,'Userdata',I4);
end

for i=1:maxX
    for j=1:maxY
        if IX2(i,j)==2
            IMMM(i,j)=200;
        else
            IMMM(i,j)=1;
        end
    end
end 
segmentedOutput = I4;
if(flag)
% figure, subplot(121), imshow(IMMM), subplot(122), imshow(IMMM,[])
end
% ffcm1=(['The 1st Cluster = ' num2str(ccc1)]);
% ffcm2=(['The 2nd Cluster = ' num2str(ccc2)]);
% % set(handles.fcm1,'String',ffcm1);
% set(handles.fcm2,'String',ffcm2);

end

