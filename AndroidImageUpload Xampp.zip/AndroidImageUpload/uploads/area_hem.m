function [area_hemorhage,new_area] = area_hem( green_channel,img_bin, up_Lim, low_Lim )
flag  = 0;

region_of_interest=ROI(green_channel,0);
% img1 is resized image
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
%  %retinal_image=imread('G:\study material\Bs-vii\FYP\DR project\B. Disease Grading\1. Original Images\a. Training Set');
%  image_something = im2double(retinal_image(:,:,2));
%  image_something2 = image_something.^2;
%  figure, subplot(1,2,1), imshow(image_something), subplot(1,2,2), imshow(image_something2,[])
%  impixelinfo

% [fname, path]=uigetfile('*.jpg','select an image');
% fname=strcat(path, fname);
% img=imread(fname);
% img = imread('IDRiD_31.jpg');
% img = imread('test.jpg');
% img1=imresize(img,[500,700],'nearest');
% img2=img1(:,:,2);
% 
% img3=imcomplement(img2);
%  img4=adapthisteq(img3);
%  unSharp=imsharpen(img4);
% H = fspecial('gaussian',[9,9],1.5);
% img_gauss = imfilter(img4, H);
% abs_diff = abs(img4 - img_gauss);
% img_bin = unSharp>210;
% figure, imshow(img_bin)
%%
if(flag)
imshow(img_bin);
end


connected= bwconncomp(img_bin);
numObjects=connected.NumObjects;
img_final = img_bin.*0;
PixIndexes = connected.PixelIdxList;
sum1 = 0;
img_test = zeros(size(img_bin));
%     numPixels = cellfun(@numel,PixIndexes);
for i = 1:length(PixIndexes)
    
    if (length(PixIndexes{1,i})>low_Lim&&length(PixIndexes{1,i})<up_Lim)
        
       img_bin(PixIndexes{1,i}) = 0; 
    end
    if(length(PixIndexes{1,i})>=up_Lim)
       sum1 = sum1 + length(PixIndexes{1,i})<up_Lim;
       img_test(PixIndexes{1,i}) = 1;
    end
    
end
  StructImg=bwconncomp(img_test);
 PixIndexes = StructImg.PixelIdxList;
 numPix = sort(cellfun(@numel, PixIndexes),'descend');
 vessel_area_hem=sum(numPix);
total_pix=sum(img_test(:));

area_hemorhage=total_pix/region_of_interest;
new_area=vessel_area_hem/region_of_interest;


end

