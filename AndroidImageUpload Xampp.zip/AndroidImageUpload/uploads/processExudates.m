
function [exudates,proportion_exudates]= processExudates(x)
close all;
z=num2str(x);
path=strcat('C:\xampp\htdocs\AndroidImageUpload\uploads\',z);
fpath=strcat(path,'.jpg');


% [fname, path]=uigetfile('*.jpg','select an image');
% fname=strcat(path, fname);



img=imread(fpath);


img1=imresize(img,[500,700],'nearest');
img2=img1(:,:,2);
 img3=adapthisteq(img2);
 [M,N]=size(img3);
 image1 = zeros(M,N);
 image2 = zeros(M,N);
 image3 = zeros(M,N);
 image4 = zeros(M,N);
 
 im3_double = double(img3);
 exp_image = exp(255-im3_double);
figure, imshow(exp_image,[]);
 z = zeros(M,N);
 
 z=[];
        for x = 1:M
            for y = 1:N
                m=im3_double(x,y);
                    if(m>=0 && m<=50)
                     
                     image1(x,y) = log10(1+m)/log10(5);
                    end
                     
                    if(m>50 && m<=150)
                            z(x,y)=log10(1+m)/log10(4);
                            image2(x,y) = log10(1+m)/log10(4);
                    end
                    
                    
                    if(m>150 && m<=200)
                       
                            z(x,y)=log10(1+m)/log10(2);
                            image3(x,y) = log10(1+m)/log10(2);
                    end
                    
                    
                    if(m>200 && m<=255)
                            z(x,y)=log10(1+m)/log10(1);
                            image4(x,y) =1; 
                    end
                    
                    
                   
            end
        end

 
 
 
subplot(2,2,1),imshow(img1),title('binary_image');
 z = mat2gray(z);
 subplot(2,2,2),imshow(z,[]),title('binary_image');
 disk_strEl = strel('disk', 5,4);
%  eroded_z = imerode(z, disk_strEl);
%  figure, imshow(eroded_z),title('Erosion');
SE=strel('disk',15);
img5=imerode(image4, SE);
subplot(2,2,3), imshow(img5),title('Erosion Struction Element 15');
img6=imdilate(img5, SE);
subplot(2,2,4), imshow(img6),title('Dilation');
% StructImg=bwconncomp(image4);
% PixIndexes = StructImg.PixelIdxList;
% numPix = cellfun(@numel, PixIndexes);
% [biggest, idx] = max(numPix);
% 
% [row_idx, col_idx] = ind2sub([M,N],PixIndexes{idx});
% min_row = min(row_idx);
% max_row = max(row_idx);
%  
% min_col = min(col_idx);
% max_col = max(col_idx);
% diff_col = max_col - min_col;
% diff_row = max_row - min_row;
% if(diff_row>diff_col)
%     rad_StrEl = (max_row - min_row)/2;
% else
%     rad_StrEl = (max_col - min_col)/2;
% end
% rad_StrEl = round(rad_StrEl);
% cent_row = min_row + rad_StrEl;
% cent_col = min_col + rad_StrEl;
% size_pixInd = length(PixIndexes);
% image_zeros = zeros(size(image4));
% image_temp = image_zeros;
% for i = 1:size_pixInd
%     temp_array = cell2mat(PixIndexes(i));
%     image_temp(temp_array) = i;
%     
% end
% patch_image = image_temp(cent_row-rad_StrEl*2:cent_row+rad_StrEl*2,cent_col-rad_StrEl*2:cent_col+rad_StrEl*2);
% image_zeros(cent_row, cent_col) = 1;
% unique_st = unique(patch_image);
% unique_st(unique_st==0) = [];
% for i = 1:length(unique_st)
%     image_zeros(PixIndexes{unique_st(i)}) = 1;
%     
% end
% [row_group, col_group] = find(image_zeros==1);
% 
% 
% min_row = min(row_group);
% max_row = max(row_group);
% 
% min_col = min(col_group);
% max_col = max(col_group);
% diff_col = max_col - min_col;
% diff_row = max_row - min_row;
% if(diff_row>diff_col)
%     rad_StrEl = (max_row - min_row)/2;
% else
%     rad_StrEl = (max_col - min_col)/2;
% end
% 
% 
% % image_zeros(PixIndexes{idx}) = 1;
% % figure,subplot(1,3,1), imshow(img1),title('original img'),subplot(1,3,2), imshow(image_zeros),title('extracted disk region'),subplot(1,3,3), imshow(image_temp),title('total region')
% image_temp = image_temp>0;
% exudates = image_temp - image_zeros;
% figure, imshow(exudates)
% sum_exudates = sum(exudates(:));
% proportion_exudates = 100*sum_exudates/(M*N);
% fprintf('this is proportion:%s\n',proportion_exudates);
% 
% title('Exudates')
% strElDisk = strel('disk',ceil(rad_StrEl),8);
% dilated_diskImg = imdilate(image_zeros, strElDisk);
% fileID = fopen('C:\\Users\\Simran\\FinalOutput.txt','w');
% fprintf(fileID,'%6.2f\n',proportion_exudates);
%  fclose(fileID);
% figure, imshow(dilated_diskImg)

% figure(1),subplot(3,3,1), imshow(img),title('original');
% subplot(3,3,2), imshow(img2),title('green channel');
% subplot(3,3,3), imshow(img3),title('CLAHE');
% subplot(3,3,4), imshow(image4),title('required ');
% subplot(3,3,5), imshow(image_zeros),title('location dot');
% subplot(3,3,6), imshow(dilated_diskImg),title('dilated');


% figure(1),subplot(3,3,1), imshow(img),title('original');
% subplot(3,3,2), imshow(img2),title('green channel');
% subplot(3,3,3), imshow(img3),title('CLAHE');
% subplot(3,3,4), imshow(image4),title('required ');
% subplot(3,3,5), imshow(image_zeros),title('location dot');
% subplot(3,3,6), imshow(dilated_diskImg),title('dilated');



original_img=imread(fpath);

img_resize=imresize(original_img,[500,700],'nearest');
green_channel=img_resize(:,:,2);
innvert_img=imcomplement(green_channel);
clahe_img=adapthisteq(innvert_img);
canny_img=edge(clahe_img,'canny');
figure, imshow(canny_img),title('Canny img');
 %cannyI=cannydetector(clahe_img);
 fill=imfill(canny_img,'holes');
figure, imshow(fill),title('fill holes');

subtracted_img=fill-canny_img;%imsubtract(fill,canny_img);
figure, imshow(subtracted_img),title('subtracted_img');
 [M,N]=size(subtracted_img);
  finalImage=zeros(M,N);
connected= bwconncomp(subtracted_img);
PixIndexes = connected.PixelIdxList;
    numPixels = cellfun(@numel,PixIndexes);
for i=1:connected.NumObjects
  
    PixIndexes = connected.PixelIdxList;
    numPixels = cellfun(@numel,PixIndexes);
    [biggest,idx] = max(numPixels);
    [minimumPixels,idmin]= min(numPixels);
    
    if(biggest>9)
        subtracted_img(PixIndexes{idx})=0;
       
    end
    if(minimumPixels<7)
        subtracted_img(PixIndexes{idmin})=0;
    end
     connected= bwconncomp(subtracted_img);
end
figure, imshow(subtracted_img),title('final Image');
 connected= bwconncomp(subtracted_img);
 
%  disp(connected.NumObjects);

        







%figure,subplot(3,3,1),imshow(clahe_img),title('Original Image');
  


% figure,subplot(3,3,1),imshow(original_img),title('Original Image');subplot(3,3,2),imshow(green_channel),title('Green channel Image');
% subplot(3,3,3),imshow(innvert_img),title('Innvert Image');
% subplot(3,3,4),imshow(clahe_img),title('CLAHE Image');
% subplot(3,3,5),imshow(canny_img),title('Canny  Image');
% subplot(3,3,8),imshow(fill),title('subtract');
end