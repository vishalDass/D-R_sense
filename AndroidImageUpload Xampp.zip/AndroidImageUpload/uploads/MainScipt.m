clc; close all; clear all;
length_imgs = 413;
numFeatures = 10;
mat_Features = zeros(length_imgs, numFeatures);

idx=0;
% j = [9 14 19 25 26 30]
for i=1:length_imgs
% for k=1:length(j)
% i = j(k);
path='F:\\BSCS VII\\FYP\\DRIMDB\\B. Disease Grading\\1. Original Images\\a. Training Set\\';
if(i>99)
    fname=['IDRiD_' num2str(i) '.jpg'];
else
fname=['IDRiD_0' num2str(i) '.jpg'];
end
% [fname, path]=uigetfile('*.jpg','select an image');
fname=strcat(path, fname);
input_image=imread(fname);
% figure(i),imshow(input_image),title(fname);

%-------------->


image_resize=imresize(input_image,[500,700],'nearest');
green_channel=(image_resize(:,:,2));

%-------------->
%..................Exudates features.........................
[exudates_area,diam,seg_mean_ex,seg_sd_ex]=exudates_detection(green_channel);


% ......................Hemorhage Vessel Features................
[someVal,bin_ROI] = ROI(green_channel,0);
[segmentedOutput, area, var_diff] = vesselsExtraction2(green_channel);
segmentedOutput = segmentedOutput.*bin_ROI;
[area_hemorhage,new_area] = area_hem(green_channel, segmentedOutput, 100, 0 );

idx=find(segmentedOutput==1);
seg_mean_vhem=mean(double(green_channel(idx)));
seg_sd_vhem=std(double(green_channel(idx)));



% ..................................micro........................
[ num_MA,seg_mean_MA,seg_sd_MA ]=microaneurysms_detection(green_channel);


% .......................Features CSV Data...............
mat_Features(i,1) = seg_mean_ex;
mat_Features(i,2) = seg_sd_ex;
mat_Features(i,3) = exudates_area;

mat_Features(i,4) = seg_mean_vhem;
mat_Features(i,5) = seg_sd_vhem;
mat_Features(i,6) = new_area;

mat_Features(i,7) = seg_mean_MA;
mat_Features(i,8) = seg_sd_MA;
mat_Features(i,9) = num_MA;

mat_Features(i,10) = diam;
% figure(1), imshow(segmentedOutput);
% 
% 
% 
% figure(2), imshow(segmentedOutput - exudates)
% figure(3), imshow((segmentedOutput - exudates)<0)
% segmentedOutput = segmentedOutput - exudates;






% figure(4), imshow(segmentedOutput - img_test)
%-------------->
% 
% red_channel=(image_resize(:,:,1));
% 
% mean_green_channel=mean(double(green_channel(:)));
% mean_red_channel = mean(double(red_channel(:)));
%  variance_green_channel=var(double(green_channel(:)));
%  variance_red_channel=var(double(red_channel(:)));
%  
%  deviation_green_channel=std(double(green_channel(:)));
%  deviation_red_channel=std(double(red_channel(:)));
%  total_variance=variance_green_channel+variance_red_channel;
%  total_mean=mean_green_channel+mean_red_channel;
%  total_std=deviation_green_channel+deviation_red_channel;
% 
%     
%      [exudates,exudates_area,array_pixExudates,array_numExudates,top_sever_lesion,diam]=exudates_detection(green_channel);
%      array_pixExudates(2:end,:) = [];
%       array_numExudates(2:end,:) = [];
%       
%  
% 
% 
% 

% hemo_area=hemorhage_detection(green_channel);
% 
% 
% 

% sortPixEx = sort(array_pixExudates,'descend');
% if(length(sortPixEx)<8)
%         sortPixEx(length(sortPixEx)+1:8) = 0;
% end
% mat_Features(i,11:18) = sortPixEx(1:8);
% 
% 
% sortNumEx = sort(array_numExudates,'descend');
% if(length(sortNumEx)<8)
%         sortNumEx(length(sortNumEx)+1:8) = 0;
% end
% mat_Features(i,19:26) = sortNumEx(1:8);
% 
% 
% top_sever_lesion
% 
% 
% sortLes = sort(top_sever_lesion,'descend');
% if(length(sortLes)<8)
%         sortLes(length(sortLes)+1:8) = 0;
% end
% mat_Features(i,27:34) = sortLes(1:8);
% 
% mat_Features(i,35) = num_MA;
% mat_Features(i,36) = hemo_area;
% 
% mat_Features(i,37) = diam;
% mat_Features(i,38)=hemorhage_detection(green_channel);
% save featureData mat_Features
% 
% clear all
% load featureData
% 
% 
% -------------->
% end
% 
% image_resize=imresize(input_image,[500,700],'nearest');
% green_channel=(image_resize(:,:,2));
% red_channel=(image_resize(:,:,1));
% mean_green_channel=mean(double(green_channel(:)));
% mean_red_channel=mean(double(red_channel(:)));
%  variance_green_channel=var(double(green_channel(:)));
%  variance_red_channel=var(double(red_channel(:)));
%  
%  deviation_green_channel=std(double(green_channel(:)));
%  deviation_red_channel=std(double(red_channel(:)));
%  total_variance=variance_green_channel+variance_red_channel;
%  total_mean=mean_green_channel+mean_red_channel;
%  total_std=deviation_green_channel+deviation_red_channel;
% 
% [exudates_area,array_pixExudates,array_numExudates,top_sever_lesion]=exudates_detection(green_channel);
% num_MA=microaneurysms_detection(green_channel);
% hemo_area=hemorhage_detection(green_channel);
% 
% end
% figure(2), imshow(img_output)
% title(['final output' num2str(i)])
% sum(img_output(:))
% 
% someVal
% pause(1.5)
end
