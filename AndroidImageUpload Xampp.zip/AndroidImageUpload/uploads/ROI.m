function [region_of_interest, img_test1] = ROI(green_channel, thresh)
%% it takes green channel as input and return sum of pixels of ROI along with complement of ROI
image_clahe_temp=adapthisteq(imcomplement(green_channel));
image_clahe=adapthisteq(green_channel);

 unSharpImage=imsharpen(image_clahe_temp);
 extraction_imageROI = unSharpImage>210;


connected= bwconncomp(extraction_imageROI);
img_final = extraction_imageROI.*0;
PixIndexes = connected.PixelIdxList;
sum1 = 0;
%     numPixels = cellfun(@numel,PixIndexes);
img_test = ones(size(extraction_imageROI));
for i = 1:length(PixIndexes)
    
    if (length(PixIndexes{1,i})>4&&length(PixIndexes{1,i})<2000)
        
       img_final(PixIndexes{1,i}) = 1; 
    end
    if(length(PixIndexes{1,i})>=2000)
       sum1 = sum1 + length(PixIndexes{1,i})<100;
       img_test(PixIndexes{1,i}) = 0;
    end
    
end
% figure, imshow(img_test)
SE = strel('disk', 8, 0);
img_temp = imopen(1-img_test, SE);
for i=1:15
    img_test = imopen(img_temp, SE);

    
    connected= bwconncomp(img_test);
% img_final = img_test1.*0;
PixIndexes = connected.PixelIdxList;
img_test1 = zeros(size(img_test));
for j = 1:length(PixIndexes)
    
     if(length(PixIndexes{1,j})>=2000)
      % sum1 = sum1 + length(PixIndexes{1,i})<1000;
       img_test1(PixIndexes{1,j}) = 1;
    end
    
end
img_test1 = 1-img_test1;
    img_test1 = 1 - img_test1;
    
    bin_diff = img_temp - img_test1;
    img_temp = img_test1;
    %figure(1), imshow(img_test1)
    %title([num2str(i) 'th iteration opening'])
    pause(2)
    if(sum(bin_diff(:))<=thresh)
        break;
    end
end


% 
% % figure, imshow(img_test1)
% 
% connected= bwconncomp(img_test1);
% % img_final = img_test1.*0;
% PixIndexes = connected.PixelIdxList;
% % sum1 = 0;
% %     numPixels = cellfun(@numel,PixIndexes);
% img_test1 = ones(size(img_test1));
% for i = 1:length(PixIndexes)
%     
%      if(length(PixIndexes{1,i})<=2000)
%       % sum1 = sum1 + length(PixIndexes{1,i})<1000;
%        img_test1(PixIndexes{1,i}) = 0;
%     end
%     
% end

%center of ROI for quadrant detection
img_test1 = 1-img_test1 ;

% [r1,c1]=find(image_test1==1);
% 
% min_ex_row=min(r1);
% max_ex_row=max(r1);
% 
% 
% min_ex_col=min(c1);
% max_ex_col=max(c1);
% 
% r_cen=(min_ex_row+max_ex_row)/2;
% c_cen=(min_ex_col+max_ex_col)/2;


region_of_interest=sum(img_test1(:));
end

