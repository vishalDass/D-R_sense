
function [ num_MA,exudates_area,area_hemorhage] = DRSense(name)
close all;
z=num2str(name);
disp(z);
path=strcat('C:\xampp\htdocs\AndroidImageUpload\uploads\',z);

input_image=strcat(path,'.jpg');%UNTITLED Summary of this function goes here
% input_image=strcat(name,'.jpg');
disp(input_image);
%   Detailed explanation goes here
image=imread(input_image);
% figure(i),imshow(input_image),title(fname);

%-------------->


image_resize=imresize(image,[500,700],'nearest');
green_channel=(image_resize(:,:,2));

%-------------->
%..................Exudates features.........................
[exudates_image,opticDiskImage,exudates_area,diam,seg_mean_ex,seg_sd_ex]=exudates_detection(green_channel);

%   figure(10),imshow(exudates_image),title('Exudates Image');
%   figure(11),imshow(opticDiskImage),title('Optic Disk')


% ......................Hemorhage Vessel Features................
[someVal,bin_ROI] = ROI(green_channel,0);
[segmentedOutput, area, var_diff] = vesselsExtraction2(green_channel);
segmentedOutput = segmentedOutput.*bin_ROI;
 figure(8),imshow(segmentedOutput),title('Vessls');
[area_hemorhage,new_area] = area_hem(green_channel, segmentedOutput, 100, 0 );

idx=find(segmentedOutput==1);
seg_mean_vhem=mean(double(green_channel(idx)));
seg_sd_vhem=std(double(green_channel(idx)));



% ..................................micro........................
[micro_image, num_MA,seg_mean_MA,seg_sd_MA ]=microaneurysms_detection(green_channel);
% figure(9),imshow(micro_image),title('Microaneruysms');

% ........................................Subplot...............................
figure(12),subplot(3,2,1),imshow(input_image),title('Original_Image'),
           subplot(3,2,2),imshow(green_channel),title('Green Channel Image')
           subplot(3,2,3),imshow(exudates_image),title('Exudates Lesion'),
           subplot(3,2,4),imshow(opticDiskImage),title('Optic Disk'),
           subplot(3,2,5),imshow(segmentedOutput),title('Hemoraghes and vessels'),
           subplot(3,2,6),imshow(micro_image),title('Microaneruysms');
           

fileID = fopen('C:\\Users\\Simran\\Num_MA.txt','w');
fprintf(fileID,'%6.2f\n',num_MA);
fclose(fileID);

fileID = fopen('C:\\Users\\Simran\\exudates_Area.txt','w');
fprintf(fileID,'%6.2f\n',exudates_area);
fclose(fileID);

fileID = fopen('C:\\Users\\Simran\\Hemo_area.txt','w');
fprintf(fileID,'%6.2f\n',area_hemorhage);
fclose(fileID);


% .......................Features CSV Data...............
% mat_Features(i,1) = seg_mean_ex;
% mat_Features(i,2) = seg_sd_ex;
% mat_Features(i,3) = exudates_area;
% 
% mat_Features(i,4) = seg_mean_vhem;
% mat_Features(i,5) = seg_sd_vhem;
% mat_Features(i,6) = new_area;
% 
% mat_Features(i,7) = seg_mean_MA;
% mat_Features(i,8) = seg_sd_MA;
% mat_Features(i,9) = num_MA;
% 
% mat_Features(i,10) = diam;
% 
% */
% figure(1), imshow(segmentedOutput);
% 
% 
% 
% figure(2), imshow(segmentedOutput - exudates)
% figure(3), imshow((segmentedOutput - exudates)<0)
% segmentedOutput = segmentedOutput - exudates;






% figure(4), imshow(segmentedOutput - img_test)
%-------------->
% 
% red_channel=(image_resize(:,:,1));
% 
% mean_green_channel=mean(double(green_channel(:)));
% mean_red_channel = mean(double(red_channel(:)));
%  variance_green_channel=var(double(green_channel(:)));
%  variance_red_channel=var(double(red_channel(:)));
%  
%  deviation_green_channel=std(double(green_channel(:)));
%  deviation_red_channel=std(double(red_channel(:)));
%  total_variance=variance_green_channel+variance_red_channel;
%  total_mean=mean_green_channel+mean_red_channel;
%  total_std=deviation_green_channel+deviation_red_channel;
% 
%     
%      [exudates,exudates_area,array_pixExudates,array_numExudates,top_sever_lesion,diam]=exudates_detection(green_channel);
%      array_pixExudates(2:end,:) = [];
%       array_numExudates(2:end,:) = [];
%       
%  
% 
% 
% 

% hemo_area=hemorhage_detection(green_channel);
% 
% 
% 

% sortPixEx = sort(array_pixExudates,'descend');
% if(length(sortPixEx)<8)
%         sortPixEx(length(sortPixEx)+1:8) = 0;
% end
% mat_Features(i,11:18) = sortPixEx(1:8);
% 
% 
% sortNumEx = sort(array_numExudates,'descend');
% if(length(sortNumEx)<8)
%         sortNumEx(length(sortNumEx)+1:8) = 0;
% end
% mat_Features(i,19:26) = sortNumEx(1:8);
% 
% 
% top_sever_lesion
% 
% 
% sortLes = sort(top_sever_lesion,'descend');
% if(length(sortLes)<8)
%         sortLes(length(sortLes)+1:8) = 0;
% end
% mat_Features(i,27:34) = sortLes(1:8);
% 
% mat_Features(i,35) = num_MA;
% mat_Features(i,36) = hemo_area;
% 
% mat_Features(i,37) = diam;
% mat_Features(i,38)=hemorhage_detection(green_channel);
% save featureData mat_Features
% 
% clear all
% load featureData
% 
% 
% -------------->
% end
% 
% image_resize=imresize(input_image,[500,700],'nearest');
% green_channel=(image_resize(:,:,2));
% red_channel=(image_resize(:,:,1));
% mean_green_channel=mean(double(green_channel(:)));
% mean_red_channel=mean(double(red_channel(:)));
%  variance_green_channel=var(double(green_channel(:)));
%  variance_red_channel=var(double(red_channel(:)));
%  
%  deviation_green_channel=std(double(green_channel(:)));
%  deviation_red_channel=std(double(red_channel(:)));
%  total_variance=variance_green_channel+variance_red_channel;
%  total_mean=mean_green_channel+mean_red_channel;
%  total_std=deviation_green_channel+deviation_red_channel;
% 
% [exudates_area,array_pixExudates,array_numExudates,top_sever_lesion]=exudates_detection(green_channel);
% num_MA=microaneurysms_detection(green_channel);
% hemo_area=hemorhage_detection(green_channel);
% 
% end
% figure(2), imshow(img_output)
% title(['final output' num2str(i)])
% sum(img_output(:))
% 
% someVal
% pause(1.5)

end

