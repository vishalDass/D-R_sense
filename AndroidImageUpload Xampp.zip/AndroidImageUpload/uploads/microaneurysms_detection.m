function [ subtracted_img,num_MA,seg_mean_MA,seg_sd_MA ] = microaneurysms_detection(green_channel )
innvert_img=imcomplement(green_channel);
clahe_img=adapthisteq(innvert_img);
canny_img=edge(clahe_img,'canny');
%figure, imshow(canny_img),title('Canny img');
 %cannyI=cannydetector(clahe_img);
 fill=imfill(canny_img,'holes');
%figure, imshow(fill),title('fill holes');

subtracted_img=fill-canny_img;%imsubtract(fill,canny_img);
%figure, imshow(subtracted_img),title('subtracted_img');
 [M,N]=size(subtracted_img);
 finalImage=zeros(M,N);
connected= bwconncomp(subtracted_img);
PixIndexes = connected.PixelIdxList;
    numPixels = cellfun(@numel,PixIndexes);
for i=1:connected.NumObjects
  
    PixIndexes = connected.PixelIdxList;
    numPixels = cellfun(@numel,PixIndexes);
    [biggest,idx] = max(numPixels);
    [minimumPixels,idmin]= min(numPixels);
    
    if(biggest>9)
        subtracted_img(PixIndexes{idx})=0;
       
    end
    if(minimumPixels<7)
        subtracted_img(PixIndexes{idmin})=0;
    end
     connected= bwconncomp(subtracted_img);
end
% figure, imshow(subtracted_img),title('final Image');
 connected= bwconncomp(subtracted_img);
 
 disp(connected.NumObjects);

 num_MA= connected.NumObjects;
 
 idx=find(subtracted_img==1);
 seg_mean_MA=mean(double(green_channel(idx)));
seg_sd_MA=std(double(green_channel(idx)));


% figure,subplot(3,2,1),imshow(original_img),title('Original Image'),subplot(3,2,2), imshow(canny_img),title('Canny img'),subplot(3,2,3),imshow(fill),title('fill holes'),
% subplot(3,2,4),imshow(subtracted_img),title('subtracted_img'),subplot(3,2,5),imshow(subtracted_img),title('final Image');

  


% figure,subplot(3,3,1),imshow(original_img),title('Original Image');subplot(3,3,2),imshow(green_channel),title('Green channel Image');
% subplot(3,3,2),imshow(innvert_img),title('Innvert Image');
% subplot(3,3,3),imshow(clahe_img),title('CLAHE Image');
% subplot(3,3,4),imshow(canny_img),title('Canny  Image');
% subplot(3,3,5),imshow(fill),title('Fill Holes');
% subplot(3,3,6),imshow(fill),title('Subtracted Image');
% subplot(3,3,7),imshow(fill),title('Final Micro');
% 


end

