<?php

require_once 'dbDetails.php';

		$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect...');
		$sql = "SELECT max(id) as id FROM images";
		$queryresult = mysqli_query($con,$sql);
                
                  
if(mysqli_num_rows($queryresult)>0)
	{  
           echo "success";
          $result=mysqli_fetch_row($queryresult);
          $imageName=$result[0];
         
          echo $imageName;
	}
	else
 	    echo "invalid";

echo $email;

?>