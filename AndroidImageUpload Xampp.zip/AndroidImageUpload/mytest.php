<?php

exec("\"C:\\Program Files (x86)\\MATLAB\\MATLAB Production Server\\R2015a\\bin\\matlab.exe\" -nodisplay -nosplash -nodesktop -r \"run('C:\\Users\\Simran\\test('shanti')')\"");

?>